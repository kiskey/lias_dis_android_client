#!/usr/bin/env bash
set -euo pipefail

chmod +x apply_batch_011_plan31_home_ux_audit.sh \
  apply_batch_012_plan31_home_card_interactions.sh \
  apply_batch_013_plan31_active_protections_tag_deeplink.sh \
  apply_batch_014_plan31_icon_contract_verification.sh

./apply_batch_011_plan31_home_ux_audit.sh
./apply_batch_012_plan31_home_card_interactions.sh
./apply_batch_013_plan31_active_protections_tag_deeplink.sh
./apply_batch_014_plan31_icon_contract_verification.sh

echo "Plan 3.1 Home UX batches completed. Push and run GitHub Actions."
