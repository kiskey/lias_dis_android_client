#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 014 — Plan 3.1 icon and contract verification
# Run from repository root.
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p docs scripts build/plan31

cat > docs/compose_cupertino_plan31_icon_gap_report.md <<'EOF'
# Plan 3.1 Cupertino icon gap report

Status: review note

The Plan 3.0 migration evidence verified that the maintained fork contains the
currently referenced LIAS icons and specific search icons such as
`MagnifyingGlass` and `XmarkCircle`.

For the requested Home-card trailing disclosure, this patch set does not claim
that a specific maintained-fork `ChevronRight` / disclosure vector is available
unless the local source imports and compiles it. If a Cupertino chevron symbol is
not available under `com.slapps.cupertino`, the safe fallback is the iOS-style
text disclosure glyph `›` rendered with `CupertinoText`, not a Material icon.

Decision needed only if product requires a vector chevron:
- approve a confirmed `com.slapps.cupertino` icon after CI proves it resolves; or
- approve the `CupertinoText("›")` disclosure fallback; or
- provide/approve a LIAS-owned vector asset with license review.

Material icons are not approved for Plan 3.1 Home cards.
EOF

cat > scripts/verify_plan31_icons_and_contract.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

if grep -RIn --include='*.kt' 'androidx.compose.material.icons' app/src/main/java/com/lias/remote >/tmp/lias_plan31_material_icons.txt; then
  cat /tmp/lias_plan31_material_icons.txt >&2
  echo "ERROR: Material icons are not allowed in Plan 3.1 Home card changes." >&2
  exit 1
fi

if grep -RIn --include='*.kt' 'io.github.alexzhirkevich' app/src >/tmp/lias_plan31_old_cupertino.txt; then
  cat /tmp/lias_plan31_old_cupertino.txt >&2
  echo "ERROR: old Cupertino namespace remains." >&2
  exit 1
fi

if grep -RIn --include='*.kt' -E 'api/v2|/api/v1/.*/refresh|device_id.*policy|nftables|netlink|Pi-hole|Avahi|nmap' app/src/main/java/com/lias/remote >/tmp/lias_plan31_contract_risk.txt; then
  cat /tmp/lias_plan31_contract_risk.txt
  echo "WARNING: possible contract-sensitive references found; review before merge."
fi

echo "PASS: Plan 3.1 icon/contract static verification passed."
SH
chmod +x scripts/verify_plan31_icons_and_contract.sh

scripts/verify_plan31_home_ux.sh
scripts/verify_plan31_icons_and_contract.sh

echo "Batch 014 applied: Plan 3.1 icon gap report and contract verification added."
