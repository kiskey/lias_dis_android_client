#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 011 — Plan 3.1 Home UX scope, discovery, and guards
# Run from repository root.
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p docs scripts build/plan31

cat > docs/compose_cupertino_plan31_home_ux.md <<'EOF'
# Compose Cupertino Plan 3.1 — Home UX extension

Status: implementation patch plan  
Scope: Plan 3.1 UX adoption plus explicitly requested Home-screen refinements  
Date: 2026-08-10

## Contract boundary

This is a UI-only Android change. It must not change LIAS REST paths, JSON
payloads, SSE behavior, PDID keying, repository ownership, authentication,
persistence, policy/schedule semantics, or server-authoritative enforcement.

Android remains a LIAS server client. The server remains authoritative for
identity, inventory, effective access, persistence, policy enforcement, and
event replay.

## User-approved Home-screen changes

1. Restricted device cards:
   - remove distinct visible per-card action buttons for `Extend access` and
     `Details`;
   - tapping the card opens the existing extend-access modal for that device;
   - tapping the trailing right-side disclosure opens the existing device details
     flow.

2. Active Protections group-policy cards:
   - tapping a group/tag policy card navigates to Devices already scoped to that
     specific group/tag instead of opening the generic Devices screen.

3. Cupertino/HIG visual boundary:
   - continue using the maintained `com.slapps.cupertino` package;
   - do not introduce Material icons into Home cards;
   - prefer Cupertino icons already present in the maintained fork;
   - if a disclosure/chevron icon cannot be verified, use a text disclosure glyph
     as a safe fallback and record the gap.

## Non-goals

- No new LIAS/DIS endpoint.
- No identity mutation behavior change.
- No device-policy semantics change.
- No local discovery/correlation.
- No bottom-sheet host migration unless separately approved.
- No replacement of REST/SSE models.
- No new public Kotlin contract unless a patch explicitly records it.

## Acceptance criteria

- Debug and release builds pass in GitHub Actions.
- Existing unit/contract tests pass.
- Restricted device card tap opens the same extend-access modal formerly opened
  by the `Extend access` button.
- Restricted device trailing disclosure opens the same details flow formerly
  opened by the `Details` button.
- Active Protections group-policy card opens Devices scoped to that group/tag.
- Home cards do not import Material icons.
- Old Cupertino package `io.github.alexzhirkevich` remains absent.
- Existing routes continue to work.
- No server/API/PDID/persistence/policy behavior changes.
EOF

cat > scripts/audit_plan31_home_ux.py <<'PY'
#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path.cwd()
SRC = ROOT / "app" / "src"
OUT = ROOT / "build" / "plan31" / "home_ux_audit.json"

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def score_home(text: str) -> int:
    score = 0
    for token in [
        "Active Protections",
        "Restricted",
        "Extend access",
        "Details",
        "Home",
        "Vacation",
        "Protection",
    ]:
        if token in text:
            score += 1
    return score

def score_nav(text: str) -> int:
    score = 0
    for token in ["NavHost", "composable", "Devices", "Home", "Navigation"]:
        if token in text:
            score += 1
    return score

def score_devices(text: str) -> int:
    score = 0
    for token in ["DevicesScreen", "Devices", "Tag", "Filter", "Search"]:
        if token in text:
            score += 1
    return score

kt_files = sorted(SRC.rglob("*.kt"))

home_candidates = []
nav_candidates = []
devices_candidates = []
cupertino_import_gaps = []
material_icon_imports = []
old_cupertino_refs = []

for path in kt_files:
    rel = str(path.relative_to(ROOT))
    text = read(path)
    hs = score_home(text)
    ns = score_nav(text)
    ds = score_devices(text)

    if hs >= 3:
        home_candidates.append({"path": rel, "score": hs})
    if ns >= 3:
        nav_candidates.append({"path": rel, "score": ns})
    if ds >= 3:
        devices_candidates.append({"path": rel, "score": ds})

    if "io.github.alexzhirkevich" in text:
        old_cupertino_refs.append(rel)
    if re.search(r"import\s+androidx\.compose\.material\.icons", text):
        material_icon_imports.append(rel)
    if "Cupertino" in text and "com.slapps.cupertino" not in text and "package " in text:
        cupertino_import_gaps.append(rel)

report = {
    "home_candidates": home_candidates[:10],
    "nav_candidates": nav_candidates[:10],
    "devices_candidates": devices_candidates[:10],
    "old_cupertino_refs": old_cupertino_refs,
    "material_icon_imports": material_icon_imports,
    "cupertino_import_gaps": cupertino_import_gaps[:30],
    "recommended_env_overrides": {
        "PLAN31_HOME_FILE": home_candidates[0]["path"] if home_candidates else "",
        "PLAN31_NAV_FILE": nav_candidates[0]["path"] if nav_candidates else "",
        "PLAN31_DEVICES_FILE": devices_candidates[0]["path"] if devices_candidates else "",
    },
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))

if not home_candidates:
    raise SystemExit("ERROR: no Home-screen candidate found. Set PLAN31_HOME_FILE manually.")
if old_cupertino_refs:
    raise SystemExit("ERROR: old Cupertino namespace remains in Kotlin source.")
PY
chmod +x scripts/audit_plan31_home_ux.py

cat > scripts/verify_plan31_home_ux.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from repository root." >&2
  exit 1
fi

python3 scripts/audit_plan31_home_ux.py >/tmp/lias_plan31_home_audit.log
cat /tmp/lias_plan31_home_audit.log

if grep -RIn --include='*.kt' 'io.github.alexzhirkevich' app/src >/tmp/lias_plan31_old_cupertino.txt; then
  cat /tmp/lias_plan31_old_cupertino.txt >&2
  echo "ERROR: old Cupertino namespace remains." >&2
  exit 1
fi

if grep -RIn --include='*.kt' 'androidx.compose.material.icons' app/src/main/java/com/lias/remote >/tmp/lias_plan31_material_icons.txt; then
  cat /tmp/lias_plan31_material_icons.txt >&2
  echo "ERROR: Material icons are present in app source. Plan 3.1 Home cards must stay Cupertino-owned." >&2
  exit 1
fi

echo "PASS: Plan 3.1 Home UX static audit passed."
echo "NOTE: build/test/lint must still pass in GitHub Actions."
SH
chmod +x scripts/verify_plan31_home_ux.sh

cat > .github/workflows/lias-android-plan31-home-ux.yml <<'YAML'
name: LIAS Android Plan 3.1 Home UX

on:
  workflow_dispatch:
  push:
    branches:
      - luna

jobs:
  validate-plan31-home-ux:
    runs-on: ubuntu-latest
    timeout-minutes: 45

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Set up Gradle 8.11.1
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.11.1"

      - name: Plan 3.1 static Home UX audit
        run: |
          chmod +x scripts/audit_plan31_home_ux.py scripts/verify_plan31_home_ux.sh
          scripts/verify_plan31_home_ux.sh

      - name: Compile, test, lint, package
        run: |
          gradle \
            :app:compileDebugKotlin \
            :app:compileReleaseKotlin \
            :app:testDebugUnitTest \
            :app:lintDebug \
            :app:assembleRelease \
            --stacktrace

      - name: Dependency reports
        run: |
          mkdir -p build/plan31-reports
          gradle :app:dependencies --configuration debugRuntimeClasspath > build/plan31-reports/debugRuntimeClasspath.txt
          gradle :app:dependencies --configuration releaseRuntimeClasspath > build/plan31-reports/releaseRuntimeClasspath.txt
          if grep -RIn 'io.github.alexzhirkevich' build/plan31-reports; then
            echo "Old Compose Cupertino group resolved in runtime dependency graph." >&2
            exit 1
          fi
YAML

echo "Batch 011 applied: Plan 3.1 Home UX scope, audit, and CI workflow added."
echo "Run: scripts/verify_plan31_home_ux.sh"
