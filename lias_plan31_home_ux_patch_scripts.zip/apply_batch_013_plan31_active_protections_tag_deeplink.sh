#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 013 — Plan 3.1 Active Protections tag deep-link preparation
# Run from repository root.
#
# Adds a reviewable route contract document and a local verifier. This does
# not change server/API behavior. Source patching is guarded because route
# names differ across local batches.
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p docs scripts build/plan31

cat >> docs/compose_cupertino_plan31_home_ux.md <<'EOF'

## Active Protections tag deep-link implementation contract

The accepted behavior is:

- Home Active Protections group/tag policy card click navigates to Devices with
  a selected group/tag filter.
- The Devices destination must still work with no filter.
- The selected filter is presentation/navigation state only; it must not change
  server state or policy evaluation.
- The tag key passed through navigation must be URL-encoded if carried in a route.
- If the existing navigation architecture cannot accept route arguments without
  a wider public route change, stop and record the gap before changing routes.

EOF

cat > scripts/apply_plan31_active_protections_tag_deeplink.py <<'PY'
#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
from pathlib import Path

ROOT = Path.cwd()
SRC = ROOT / "app" / "src"
REPORT = ROOT / "build" / "plan31" / "active_protections_deeplink_report.md"

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def write_report(lines):
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")

def find_file(env_name, scores):
    override = os.environ.get(env_name, "").strip()
    if override:
        p = ROOT / override
        if p.exists():
            return p
        raise SystemExit(f"ERROR: {env_name} does not exist: {override}")

    candidates = []
    for p in SRC.rglob("*.kt"):
        t = read(p)
        score = sum(tok in t for tok in scores)
        if score >= max(2, min(4, len(scores) - 1)):
            candidates.append((score, p))
    candidates.sort(reverse=True)
    return candidates[0][1] if candidates else None

home = find_file("PLAN31_HOME_FILE", ["Active Protections", "Devices", "Tag", "Protection", "Home"])
nav = find_file("PLAN31_NAV_FILE", ["NavHost", "composable", "Devices", "Home"])
devices = find_file("PLAN31_DEVICES_FILE", ["DevicesScreen", "Devices", "Tag", "Search", "Filter"])

report = [
    "# Plan 3.1 Active Protections tag deep-link report",
    "",
    f"Home candidate: `{home.relative_to(ROOT) if home else ''}`",
    f"Nav candidate: `{nav.relative_to(ROOT) if nav else ''}`",
    f"Devices candidate: `{devices.relative_to(ROOT) if devices else ''}`",
    "",
]

if not home or not nav or not devices:
    write_report(report + [
        "ERROR: could not discover all required files.",
        "Set PLAN31_HOME_FILE, PLAN31_NAV_FILE, and PLAN31_DEVICES_FILE and rerun.",
    ])
    raise SystemExit(f"ERROR: discovery incomplete. See {REPORT}")

home_text = read(home)
nav_text = read(nav)
devices_text = read(devices)

# This batch is intentionally conservative. It records candidate files and
# verifies whether an argument-capable Devices route already exists.
has_devices_arg_route = bool(re.search(r'Devices[^"\']*\{[^}]*tag|tag(Id|Key|Name)|selectedTag', nav_text + devices_text, re.I))
has_home_active_callback = bool(re.search(r'on\w*(Devices|Tag|Group)\w*\s*[:=]', home_text))

write_report(report + [
    f"Detected Devices tag/filter route support: {has_devices_arg_route}",
    f"Detected Home Active Protection callback candidate: {has_home_active_callback}",
    "",
    "Batch result:",
    "- No source route was changed automatically because route signatures are a public UI/navigation surface.",
    "- If the route support is already present, wire Home card click to that existing filtered Devices callback.",
    "- If route support is absent, add it as a separate reviewed patch with URL encoding and default no-filter compatibility.",
])

if not has_devices_arg_route:
    raise SystemExit(
        "ERROR: Devices tag-filter route support was not detected. "
        f"See {REPORT}; exact route patch required."
    )

print("PASS: route support appears present. Review report and wire Home callback if needed.")
print(f"Report: {REPORT}")
PY
chmod +x scripts/apply_plan31_active_protections_tag_deeplink.py

python3 scripts/apply_plan31_active_protections_tag_deeplink.py || {
  echo "Batch 013 stopped safely; see build/plan31/active_protections_deeplink_report.md"
  exit 1
}

scripts/verify_plan31_home_ux.sh
echo "Batch 013 applied/verified."
