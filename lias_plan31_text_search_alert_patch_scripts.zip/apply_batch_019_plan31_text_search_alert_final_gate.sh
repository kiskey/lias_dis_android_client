#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 019 — Plan 3.1 text/search/alert final gate
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p build/plan31

scripts/verify_plan31_text_search_alerts.sh

if [[ -x scripts/verify_plan31_home_ux.sh ]]; then
  scripts/verify_plan31_home_ux.sh
fi

if [[ -x scripts/verify_plan31_icons_and_contract.sh ]]; then
  scripts/verify_plan31_icons_and_contract.sh
fi

cat > build/plan31/text_search_alerts_final_gate.md <<'EOF'
# Plan 3.1 text/search/alert final gate

Local static gate passed.

Remote acceptance still requires GitHub Actions workflow:

`LIAS Android Plan 3.1 Text Search Alerts`

Expected remote checks:
- compileDebugKotlin
- compileReleaseKotlin
- testDebugUnitTest
- lintDebug
- assembleRelease
- runtime dependency reports without old Cupertino group
EOF

echo "Batch 019 applied: final local static gate passed."
echo "Push and run GitHub Actions workflow: LIAS Android Plan 3.1 Text Search Alerts"
