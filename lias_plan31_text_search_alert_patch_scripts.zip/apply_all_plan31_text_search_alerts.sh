#!/usr/bin/env bash
set -euo pipefail

chmod +x apply_batch_016_plan31_text_search_alert_audit.sh \
  apply_batch_017_plan31_field_search_hardening.sh \
  apply_batch_018_plan31_alert_candidate_audit.sh \
  apply_batch_019_plan31_text_search_alert_final_gate.sh

./apply_batch_016_plan31_text_search_alert_audit.sh
./apply_batch_017_plan31_field_search_hardening.sh
./apply_batch_018_plan31_alert_candidate_audit.sh
./apply_batch_019_plan31_text_search_alert_final_gate.sh

echo "Plan 3.1 text/search/alert slice scripts completed. Push and run GitHub Actions."
