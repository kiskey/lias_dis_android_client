#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 016 — Plan 3.1 text/search/alert scope, audit, and CI
#
# Scope:
#   - Verifies LIAS-owned HigField/HigSearchField adapter boundary.
#   - Verifies maintained-fork Cupertino text-field/search icon usage.
#   - Audits short confirmation dialog candidates.
#   - Adds remote CI workflow for this Plan 3.1 slice.
#
# Non-scope:
#   - No REST/SSE/PDID/persistence/policy/schedule changes.
#   - No server/reference repo changes.
#   - No bottom-sheet host migration.
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p docs scripts build/plan31 .github/workflows

cat > docs/compose_cupertino_plan31_text_search_alerts.md <<'EOF'
# Compose Cupertino Plan 3.1 — text fields, search, and alerts

Status: implementation/audit slice  
Date: 2026-08-10

## Contract boundary

This is a UI adapter/presentation slice only. It must not change:

- LIAS REST paths, methods, request DTOs, response DTOs, or error taxonomy;
- SSE event names, cursor behavior, replay behavior, or unknown-event handling;
- PDID keying or the displayed identity fallback order;
- repository ownership, synchronization authority, persistence, authentication,
  policy semantics, schedule semantics, or server-authoritative enforcement;
- any reference LIAS/DIS server code.

## Approved Plan 3.1 scope

1. Text fields:
   - keep the public `HigField(String, ...)` API;
   - internally use the maintained fork's `CupertinoTextField(TextFieldValue, ...)`
     through LIAS-owned adapter code;
   - preserve caller-owned `String`, cursor selection, IME composition, keyboard
     options/actions, disabled/read-only behavior, and accessibility.

2. Search:
   - keep `HigSearchField(query: String, ...)` as the public app adapter;
   - use maintained-fork Cupertino icons for search/clear affordances;
   - do not use Canvas-drawn search or clear glyphs;
   - use `CursorSafeTextField` unless `CupertinoSearchTextField` is separately
     proven against long-query cursor selection, cancellation, restoration,
     accessibility, and CI.

3. Alerts:
   - only short non-editing confirmations are candidates for
     `CupertinoAlertDialog`;
   - crowded multi-field forms remain sheets/forms;
   - alert adoption must not change mutation semantics, destructive-operation
     safeguards, or confirmation text meaning;
   - if no safe short confirmation candidate is detected, record an audit gap
     rather than guessing a source rewrite.

## Acceptance criteria

- `HigField.kt` uses `com.slapps.cupertino.CupertinoTextField`.
- `CursorSafeTextField` retains `TextFieldValue` and reconciliation behavior.
- `HigLargeTitleScaffold.kt` search uses `CursorSafeTextField`.
- Search/clear icons are from `com.slapps.cupertino.icons`.
- No `Canvas` search/clear glyphs remain in LIAS-owned search adapter code.
- No `io.github.alexzhirkevich` namespace remains.
- No Material `AlertDialog` is introduced for this slice.
- Android compile/test/lint/release package pass in GitHub Actions.
- No app source under `core`, `network`, or repository/model layers is modified
  by this slice except tests/docs/scripts/workflows.
EOF

cat > scripts/audit_plan31_text_search_alerts.py <<'PY'
#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path.cwd()
APP = ROOT / "app" / "src" / "main" / "java"
OUT = ROOT / "build" / "plan31" / "text_search_alert_audit.json"

HIG_FIELD = APP / "com" / "lias" / "remote" / "ui" / "components" / "HigField.kt"
HIG_SCAFFOLD = APP / "com" / "lias" / "remote" / "ui" / "components" / "HigLargeTitleScaffold.kt"

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def find_files(pattern: str) -> list[str]:
    found = []
    for p in APP.rglob("*.kt"):
        text = read(p)
        if re.search(pattern, text):
            found.append(str(p.relative_to(ROOT)))
    return sorted(found)

hig_field = read(HIG_FIELD)
hig_scaffold = read(HIG_SCAFFOLD)

report = {
    "files": {
        "HigField.kt": str(HIG_FIELD.relative_to(ROOT)) if HIG_FIELD.exists() else None,
        "HigLargeTitleScaffold.kt": str(HIG_SCAFFOLD.relative_to(ROOT)) if HIG_SCAFFOLD.exists() else None,
    },
    "checks": {
        "hig_field_uses_cupertino_text_field": "com.slapps.cupertino.CupertinoTextField" in hig_field,
        "hig_field_uses_text_field_value": "TextFieldValue" in hig_field,
        "hig_field_has_reconcile_editor_value": "reconcileEditorValue" in hig_field,
        "search_uses_cursor_safe_text_field": "CursorSafeTextField(" in hig_scaffold,
        "search_uses_magnifying_glass_icon": "MagnifyingGlass" in hig_scaffold and "com.slapps.cupertino.icons" in hig_scaffold,
        "search_uses_xmark_circle_icon": "XmarkCircle" in hig_scaffold and "com.slapps.cupertino.icons" in hig_scaffold,
        "search_has_ime_search": "ImeAction.Search" in hig_scaffold,
        "search_adapter_uses_no_canvas": "Canvas(" not in hig_scaffold and "draw" not in hig_scaffold.lower(),
    },
    "old_cupertino_refs": find_files(r"io\.github\.alexzhirkevich"),
    "material_alert_dialog_refs": find_files(r"androidx\.compose\.material.*AlertDialog|androidx\.compose\.material3.*AlertDialog"),
    "platform_dialog_refs": find_files(r"androidx\.compose\.ui\.window\.Dialog|Popup\("),
    "basic_text_field_refs": find_files(r"\bBasicTextField\b"),
    "canvas_refs_in_components": [
        path for path in find_files(r"\bCanvas\s*\(")
        if "/ui/components/" in path
    ],
    "short_confirmation_candidates": find_files(r"Delete|Remove|Confirm|Cancel|destructive|warning|Are you sure|cannot be undone"),
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))

failures = []
for key, ok in report["checks"].items():
    if not ok:
        failures.append(key)

if report["old_cupertino_refs"]:
    failures.append("old_cupertino_refs")
if report["material_alert_dialog_refs"]:
    failures.append("material_alert_dialog_refs")
if report["canvas_refs_in_components"]:
    failures.append("canvas_refs_in_components")

# BasicTextField is allowed only if it is outside LIAS-owned Hig adapters and
# not part of search/field code. Report it, but fail only for adapters.
adapter_basic = [
    p for p in report["basic_text_field_refs"]
    if p.endswith("HigField.kt") or p.endswith("HigLargeTitleScaffold.kt")
]
if adapter_basic:
    failures.append("adapter_basic_text_field_refs")

if failures:
    raise SystemExit("ERROR: Plan 3.1 text/search/alert audit failed: " + ", ".join(failures))
PY
chmod +x scripts/audit_plan31_text_search_alerts.py

cat > scripts/verify_plan31_text_search_alerts.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from repository root." >&2
  exit 1
fi

python3 scripts/audit_plan31_text_search_alerts.py

echo "PASS: Plan 3.1 text/search/alert static audit passed."
echo "NOTE: compile/test/lint/release packaging must still pass in GitHub Actions."
SH
chmod +x scripts/verify_plan31_text_search_alerts.sh

cat > .github/workflows/lias-android-plan31-text-search-alerts.yml <<'YAML'
name: LIAS Android Plan 3.1 Text Search Alerts

on:
  workflow_dispatch:
  push:
    branches:
      - luna

jobs:
  validate-plan31-text-search-alerts:
    runs-on: ubuntu-latest
    timeout-minutes: 45

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Set up Gradle 8.11.1
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.11.1"

      - name: Static Plan 3.1 text/search/alert audit
        run: |
          chmod +x scripts/audit_plan31_text_search_alerts.py scripts/verify_plan31_text_search_alerts.sh
          scripts/verify_plan31_text_search_alerts.sh

      - name: Compile, test, lint, package
        run: |
          gradle \
            :app:compileDebugKotlin \
            :app:compileReleaseKotlin \
            :app:testDebugUnitTest \
            :app:lintDebug \
            :app:assembleRelease \
            --stacktrace

      - name: Dependency reports
        run: |
          mkdir -p build/plan31-text-search-alerts-reports
          gradle :app:dependencies --configuration debugRuntimeClasspath > build/plan31-text-search-alerts-reports/debugRuntimeClasspath.txt
          gradle :app:dependencies --configuration releaseRuntimeClasspath > build/plan31-text-search-alerts-reports/releaseRuntimeClasspath.txt
          if grep -RIn 'io.github.alexzhirkevich' build/plan31-text-search-alerts-reports; then
            echo "Old Compose Cupertino group resolved in runtime dependency graph." >&2
            exit 1
          fi
YAML

scripts/verify_plan31_text_search_alerts.sh

echo "Batch 016 applied: Plan 3.1 text/search/alert audit and CI workflow added."
