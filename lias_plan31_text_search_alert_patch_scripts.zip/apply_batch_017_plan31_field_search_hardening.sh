#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Batch 017 — Plan 3.1 field/search adapter hardening
#
# This is mostly a verification batch because the current luna branch already
# routes HigField through CupertinoTextField(TextFieldValue) and HigSearchField
# through CursorSafeTextField with Cupertino icons. The script is idempotent
# and stops if a regression is detected.
# =====================================================================

if [[ ! -f "settings.gradle.kts" || ! -d "app/src/main/java" ]]; then
  echo "ERROR: run from the Android repository root." >&2
  exit 1
fi

mkdir -p build/plan31 docs

python3 - <<'PY'
from pathlib import Path
import re

root = Path.cwd()
hig = root / "app/src/main/java/com/lias/remote/ui/components/HigField.kt"
scaffold = root / "app/src/main/java/com/lias/remote/ui/components/HigLargeTitleScaffold.kt"
report = root / "build/plan31/batch017_field_search_report.md"

if not hig.exists():
    raise SystemExit("ERROR: HigField.kt not found")
if not scaffold.exists():
    raise SystemExit("ERROR: HigLargeTitleScaffold.kt not found")

hig_text = hig.read_text(encoding="utf-8")
scaffold_text = scaffold.read_text(encoding="utf-8")

problems = []

required_hig = [
    "import com.slapps.cupertino.CupertinoTextField",
    "TextFieldValue(",
    "TextRange(",
    "reconcileEditorValue",
    "CupertinoTextField(",
]
for token in required_hig:
    if token not in hig_text:
        problems.append(f"HigField.kt missing {token}")

required_search = [
    "fun HigSearchField(",
    "CursorSafeTextField(",
    "CupertinoIcons",
    "MagnifyingGlass",
    "XmarkCircle",
    "ImeAction.Search",
    'contentDescription = "Clear search"',
]
for token in required_search:
    if token not in scaffold_text:
        problems.append(f"HigLargeTitleScaffold.kt missing {token}")

if "BasicTextField" in hig_text:
    problems.append("HigField.kt still uses BasicTextField")
if "BasicTextField" in scaffold_text:
    problems.append("HigLargeTitleScaffold.kt search still uses BasicTextField")
if "Canvas(" in scaffold_text:
    problems.append("HigLargeTitleScaffold.kt still uses Canvas")
if "androidx.compose.material.icons" in scaffold_text or "androidx.compose.material.icons" in hig_text:
    problems.append("Material icons found in field/search adapters")

report.parent.mkdir(parents=True, exist_ok=True)

if problems:
    report.write_text(
        "# Batch 017 field/search verification failed\n\n" +
        "\n".join(f"- {p}" for p in problems) +
        "\n",
        encoding="utf-8",
    )
    raise SystemExit(f"ERROR: Batch 017 failed. See {report}")

# Add small documentation marker only, no source behavior change.
report.write_text(
    "# Batch 017 field/search verification passed\n\n"
    "- HigField uses maintained-fork CupertinoTextField(TextFieldValue).\n"
    "- CursorSafeTextField preserves cursor/selection and IME composition through TextFieldValue reconciliation.\n"
    "- HigSearchField uses CursorSafeTextField, Cupertino MagnifyingGlass, Cupertino XmarkCircle, and ImeAction.Search.\n"
    "- No Canvas or Material icon use detected in field/search adapters.\n",
    encoding="utf-8",
)

print(f"PASS: Batch 017 verification passed. Report: {report}")
PY

scripts/verify_plan31_text_search_alerts.sh

echo "Batch 017 applied: field/search adapters verified and hardened by gate."
